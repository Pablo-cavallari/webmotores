<?php
// Página de aprovação de anúncios
?>