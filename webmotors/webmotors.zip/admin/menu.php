<?php
session_start();
if ($_SESSION['tipo'] != 'ADM') {
    echo "Acesso negado!";
    exit;
}

echo "<h2>Painel do Administrador</h2>";
echo "Bem-vindo, " . $_SESSION['nome_usuario'] . "!<br><br>";

echo "<a href='aprovar.php'>📄 Aprovar Anúncios</a><br>";
echo "<a href='admin_registrar.php'>👥 Cadastrar Novo Usuário/Admin</a><br>";
echo "<a href='../logout.php'>🚪 Sair</a>";
?>