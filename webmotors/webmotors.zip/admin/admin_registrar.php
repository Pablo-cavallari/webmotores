<?php
// Página de cadastro de novo usuário/admin
?>