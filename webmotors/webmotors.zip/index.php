<?php
session_start();
include('conexao.php');

if (@$_REQUEST['botao'] == "Entrar") {
    $email = $_POST['email'];
    $senha = $_POST['senha'];

    $query = "SELECT * FROM usuarios WHERE email = '$email'";
    $result = mysqli_query($conn, $query);

    if ($coluna = mysqli_fetch_assoc($result)) {
        if (password_verify($senha, $coluna['senha'])) {
            $_SESSION["usuario_id"] = $coluna["id"];
            $_SESSION["nome_usuario"] = $coluna["nome"];
            $_SESSION["tipo"] = $coluna["tipo"];

            if ($coluna["tipo"] == "ADM") {
                header("Location: admin/menu.php");
                exit;
            } else {
                header("Location: anuncios/listar.php");
                exit;
            }
        } else {
            echo "Senha incorreta.";
        }
    } else {
        echo "Usuário não encontrado.";
    }
}
?>

<h2>Login</h2>
<form method="POST">
    Email: <input type="text" name="email" required><br>
    Senha: <input type="password" name="senha" required><br>
    <input type="submit" name="botao" value="Entrar">
</form>