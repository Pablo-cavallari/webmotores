<?php
// Página de listagem de anúncios para o usuário
?>